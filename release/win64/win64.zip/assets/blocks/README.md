# Baunilha
Fresh and tasty textures with a vanilla flavor

Baunilha is a texture pack for Luanti that aims to create a refreshed look for Minetest Game. The goal is to create an aesthetic that is cohesive, vibrant and fun to build and explore, while maintaining a vanilla feel.

## Game Support:

- Minetest Game

## Mod Support:

- Stamina
- Ethereal NG
- Baked Clay
- More ores
- Stained glass
- Bonemeal
- Dirt Path
- Scafolding
- Connected Chests
- Flower Pot