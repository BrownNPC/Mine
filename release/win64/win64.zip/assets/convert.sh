convert cubemap_0.png cubemap_1.png cubemap_2.png cubemap_3.png cubemap_4.png cubemap_5.png -append skybox.png
